package br.com.fiap.springpjchamadostecnicos.resource;

import br.com.fiap.springpjchamadostecnicos.repository.SolicitanteRepository;
import br.com.fiap.springpjchamadostecnicos.repository.EnderecoRepository;
import br.com.fiap.springpjchamadostecnicos.repository.TelefoneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@RestController
@RequestMapping(value = '/solicitante')
public class SolicitanteResource {

    @Autowired
    private SolicitanteRepository repo;

    @Autowired
    private EnderecoRepository enderecoRepository;

    @Autowired
    private TelefoneRepository telefoneRepository;

    @GetMapping
    public List<Solicitatante> findAll() {
        return repo.findAll();
    }

    @GetMapping(value = "/{id}")
    public Socilitante findById(@PathVariable Long id) {
        return repo.findById(id).orElseThrow();
    }

    @GetMapping(value = "/{id}/endereco")
    public Set<Endereco> findEndereco(@PathVariable Long id) {
        Endereco endereco = repo.findById(id).orElseThrow();
        return endereco.getEndereco();
    }
    @GetMapping(value = "/{id}/telefone")
    public Set<Telefone> findTelefone(@PathVariable Long id) {
        Telefone telefone = repo.findById(id).orElseThrow();
        return telefone.getTelefone();
    }
    @Transactional
    @PostMapping(value = "/{id}/endereco")
    public Endereco addEndereco(@PathVariable Long id, @RequestBody Endereco a) {

        Endereco endereco = repo.findById(id).orElseThrow();

        if (Objects.isNull(a)) return null;

        if (Objects.nonNull(a.getId())) {
            Endereco endereco = enderecoRepository.findById(a.getId()).orElseThrow();
            veiculo.getEndereco().add(acessorio);
            return endereco;
        }

        veiculo.getEndereco().add(a);

        return endereco;
    }
    @Transactional
    @PostMapping(value = "/{id}/telefone")
    public Telefone addTelefone(@PathVariable Long id, @RequestBody Telefone a) {

        Telefone  telefone = repo.findById(id).orElseThrow();

        if (Objects.isNull(a)) return null;

        if (Objects.nonNull(a.getId())) {
            Telefone telefone = telefoneRepository.findById(a.getId()).orElseThrow();
            telefone.getTelefone().add(telefone);
            return telefone;
        }

        telefone.getTelefone().add(a);

        return telefone;
    }

    @Transactional
    @PostMapping
    public Solicitante salvarSolicitante(@RequestBody Solicitante solicitante) {
        return repo.save(solicitante);
    }

}