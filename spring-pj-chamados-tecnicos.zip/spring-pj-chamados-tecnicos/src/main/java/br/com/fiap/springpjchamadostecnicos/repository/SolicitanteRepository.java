package br.com.fiap.springpjchamadostecnicos.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface SolicitanteRepository extends JpaRepository <Solicitante,Long> {
}