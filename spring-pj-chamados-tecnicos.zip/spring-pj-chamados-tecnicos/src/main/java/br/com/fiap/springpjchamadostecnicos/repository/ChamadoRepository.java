package br.com.fiap.springpjchamadostecnicos.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface ChamadoRepository extends JpaRepository <Chamado,Long> {
}