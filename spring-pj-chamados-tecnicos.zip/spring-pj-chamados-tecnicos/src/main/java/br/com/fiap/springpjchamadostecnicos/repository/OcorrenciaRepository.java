package br.com.fiap.springpjchamadostecnicos.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface OcorrenciaRepository extends JpaRepository <Ocorrencia,Long> {
}