package br.com.fiap.springpjchamadostecnicos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPjChamadosTecnicosApplication {

    public static void main(String[] args) {
        SpringApplication.run( SpringPjChamadosTecnicosApplication.class, args );
    }

}
