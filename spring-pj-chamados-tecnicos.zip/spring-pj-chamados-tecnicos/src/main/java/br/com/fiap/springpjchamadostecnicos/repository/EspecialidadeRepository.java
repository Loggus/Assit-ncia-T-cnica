package br.com.fiap.springpjchamadostecnicos.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface EspecialidadeRepository extends JpaRepository <Especialidade,Long> {
}