package br.com.fiap.springpjchamadostecnicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPjChamadosTecnicosApplicationTests {

    @Test
    void contextLoads() {
    }

}
